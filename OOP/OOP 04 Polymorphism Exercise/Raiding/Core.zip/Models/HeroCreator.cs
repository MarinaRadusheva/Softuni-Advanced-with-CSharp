﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Raiding.Models
{
    public abstract class HeroCreator
    {
        public abstract BaseHero CreateHero();
    }
}
