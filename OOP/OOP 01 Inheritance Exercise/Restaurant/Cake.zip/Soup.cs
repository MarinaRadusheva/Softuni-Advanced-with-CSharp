﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Restaurant
{
    public class Soup : Starter
    {
        public Soup(string nam, decimal price, double grams) : base(nam, price, grams)
        {
        }
    }
}
