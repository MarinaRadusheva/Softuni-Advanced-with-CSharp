﻿
namespace Shapes.Contracts
{
    public interface IDrawable
    {
        public void Draw();
    }
}
